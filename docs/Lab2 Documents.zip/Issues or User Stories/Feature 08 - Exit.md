As a user,
I need to be able to exit the application,
So that I'm not stuck using it forever.

Acceptance Criteria:
* When the main menu displays, there is a menu item/option to quit or exit.
* When this menu item is selected, the application ends.

Notes:
* It's ok (but not required) to display a message or ask the user to press a key before exiting.
